(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// tradewars-bet.js                                                    //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
// collection of everybody's markets                                   //
// each document is groupID, price of wood, graphite, and so on        //
// as well as                                                          //
                                                                       //
// collection of Users has groupID information as well                 //
                                                                       //
// collection of all the groups' stocks                                //
                                                                       //
AllStocks = new Mongo.Collection("stocks");                            // 9
                                                                       //
// AllMarkets = new Mongo.Collection("markets");                       //
groupIDs = ["g1", "g2", "g3", "g4"];                                   // 12
// resources = ["a", "b", "c", "d"]                                    //
                                                                       //
if (Meteor.isClient) {                                                 // 15
	// counter starts at 0                                                //
	Session.setDefault('counter', 0);                                     // 17
                                                                       //
	Template.body.helpers({                                               // 19
		userInfo: function () {                                              // 20
			return Meteor.user().profile.groupID;                               // 21
		},                                                                   //
                                                                       //
		uID: function () {                                                   // 24
			return Meteor.userId();                                             // 25
		}                                                                    //
	});                                                                   //
                                                                       //
	Template.alerts.helpers({                                             // 29
		allAlerts: function () {                                             // 30
			return Meteor.user().profile.alerts;                                // 31
		}                                                                    //
	});                                                                   //
                                                                       //
	Template.alerts.events({                                              // 35
		'submit .clear-alerts': function (event) {                           // 36
			event.preventDefault();                                             // 37
			// console.log(Meteor.user().profile.alerts)                        //
			// Meteor.users.update({_id: Meteor.userId()}, {$set: {"profile.alerts": []}});
			Meteor.call('raiseAlert', Meteor.userId(), "clearall");             // 40
		}                                                                    //
	});                                                                   //
                                                                       //
	Template.requests.helpers({                                           // 44
		allRequests: function () {                                           // 45
			// if (Meteor.user().profile.requests != undefined)                 //
                                                                       //
			return Meteor.user().profile.requests.filter(function (x) {         // 48
				return x["replied"] == false;                                      // 48
			});                                                                 //
		}                                                                    //
	});                                                                   //
                                                                       //
	Template.requests.events({                                            // 52
		"click input[type=submit]": function (e) {                           // 53
			reqno = $(e.target)[0].form.className;                              // 54
			reqs = Meteor.user().profile.requests;                              // 55
			request = reqs[reqno];                                              // 56
			acceptance = false;                                                 // 57
			if ($(e.target).prop("id") == "accept") {                           // 58
				e.preventDefault();                                                // 59
				reqResStock = AllStocks.findOne({ $and: [{ gID: Meteor.user().profile.groupID }, { item: request["reqRes"] }] });
				if (reqResStock == undefined) {                                    // 61
					Meteor.call('raiseAlert', Meteor.userId(), "Your group doesn't have the item you're trying to give! Trade fails");
					acceptance = false;                                               // 63
				} else if (reqResStock.amount < request["reqAmt"]) {               //
					Meteor.call('raiseAlert', Meteor.userId(), "Your group doesn't have enough of the item you're trying to give! Trade fails");
					acceptance = false;                                               // 67
				} else {                                                           //
					Meteor.call('exchangeResources', request);                        // 70
					Meteor.call('raiseAlert', Meteor.userId(), "Request completed, you have the things!");
					acceptance = true;                                                // 72
				}                                                                  //
				//***  add functions for making alerts, and send alert to requester about what happened ***//
			} else {                                                            //
					e.preventDefault();                                               // 77
					acceptance = false;                                               // 78
					// console.log("reject", $(e.target).prop("fNo"));                //
				}                                                                  //
                                                                       //
			if (acceptance == false) {                                          // 82
				Meteor.call('raiseAlert', request["requester"], "Request rejected/failed.");
				// Meteor.call('raiseAlert', Meteor.userId(), "Request rejected/failed.");
			} else {                                                            //
					Meteor.call('raiseAlert', request["requester"], "Request accepted! Woohoo");
					// Meteor.call('raiseAlert', Meteor.userId(), "Request rejected/failed.");
				}                                                                  //
			request.replied = true;                                             // 90
			Meteor.users.update({ _id: Meteor.userId() }, { $set: { "profile.requests": reqs } });
                                                                       //
			// Meteor.users.update({_id: Meteor.userId()}, { $set: {"profile.requests": reqs.splice(reqno, 1)} });
		}                                                                    //
	});                                                                   //
                                                                       //
	Template.stockInfo.helpers({                                          // 97
		resources: function () {                                             // 98
			groupID = Meteor.user().profile.groupID;                            // 99
			// return AllStocks.findOne({gID: groupID}).market;                 //
			return AllStocks.find({ gID: groupID });                            // 101
		}                                                                    //
                                                                       //
	});                                                                   //
                                                                       //
	Template.trade.helpers({                                              // 106
		otherUsers: function () {                                            // 107
			return Meteor.users.find({ "profile.groupID": { $ne: Meteor.user().profile.groupID } }, { _id: 1 });
		},                                                                   //
                                                                       //
		givingResources: function () {                                       // 111
			// gr = [];                                                         //
			gr = AllStocks.find({ $and: [{ "gID": Meteor.user().profile.groupID }, { "amount": { $gt: 0 } }] }, { "item": 1, "amount": 1 });
			return gr;                                                          // 114
		},                                                                   //
                                                                       //
		allResources: function () {                                          // 117
			// ar = [];                                                         //
			// ar = [{"name": "a"}, {"name": "b"}, {"name": "c"}, {"name": "d"}]
			ar = AllStocks.find({ "amount": { $gt: 0 } }, { "item": 1 }).fetch();
			distinctArray = _.uniq(ar, false, function (d) {                    // 121
				return d.item;                                                     // 121
			});                                                                 //
			distinctValues = _.pluck(distinctArray, 'item');                    // 122
			ar = distinctValues.map(function (x) {                              // 123
				return { "item": x };                                              // 123
			});                                                                 //
			return ar;                                                          // 124
		}                                                                    //
                                                                       //
	});                                                                   //
	Template.hello.helpers({                                              // 128
		counter: function () {                                               // 129
			return Session.get('counter');                                      // 130
		}                                                                    //
	});                                                                   //
                                                                       //
	Template.hello.events({                                               // 134
		'click button': function () {                                        // 135
			// increment the counter when button is clicked                     //
			Session.set('counter', Session.get('counter') + 1);                 // 137
		}                                                                    //
	});                                                                   //
                                                                       //
	Template.trade.events({                                               // 141
		"submit .trade": function (event) {                                  // 142
			// console.log("trast");                                            //
			event.preventDefault();                                             // 144
			var checkAvailability = function (res, amt) {                       // 145
				a = parseInt(AllStocks.find({ $and: [{ "gID": Meteor.user().profile.groupID }, { "item": res }, { "amount": { $gte: parseInt(amt) } }] }).fetch().length);
				// console.log(a != 0);                                            //
				if (a > 0) {                                                       // 148
					console.log("tru");                                               // 149
					return true;                                                      // 150
				} else {                                                           //
					console.log("fal");                                               // 153
					return false;                                                     // 154
				}                                                                  //
			};                                                                  //
                                                                       //
			// var alrts = Meteor.user().profile.alerts;                        //
			// console.log(alrts, Meteor.user().profile.alerts);                //
                                                                       //
			if (checkAvailability(event.target.GivingResource.value, event.target.giveAmount.value)) {
				Meteor.call('reqTrade', event.target.Recipient.value, event.target.GivingResource.value, event.target.giveAmount.value, event.target.TakingResource.value, event.target.requestAmount.value);
				// alrts.push("Sent Request");                                     //
				Meteor.call('raiseAlert', Meteor.userId(), "Sent Request");        // 164
			} else {                                                            //
				Meteor.call('raiseAlert', Meteor.userId(), "Request sending failed – probably not enough resource");
				// alrts.push("Request sending failed – probably not enough resource");
			}                                                                   //
			// Meteor.users.update({_id: Meteor.userId()}, {$set: {"profile.alerts": alrts}});
		}                                                                    //
	});                                                                   //
}                                                                      //
                                                                       //
if (Meteor.isServer) {                                                 // 177
	Meteor.startup(function () {                                          // 178
		// code to run on server at startup                                  //
                                                                       //
		//given a list of resources, choose one at random                    //
		//given a dict of resources : 0, make that random resource 1000      //
                                                                       //
		//given a dict of resources and groupID , make a document with that groupID and dict
                                                                       //
		//w                                                                  //
		// for (g in groupIDs){                                              //
		// 	console.log("adding for ", groupIDs[g]);                         //
		// 	for (r in resources){                                            //
		// 		console.log("adding ", resources[r]);                           //
		// 		AllStocks.insert({                                              //
		// 			"gID": groupIDs[g],                                            //
		// 			"item": resources[r],                                          //
		// 			"price": 150,                                                  //
		// 			"amount": 50                                                   //
		// 		});                                                             //
		// 	}                                                                //
		// }                                                                 //
                                                                       //
		Meteor.methods({                                                     // 200
			reqTrade: function (recipient, giveRes, giveAmt, takeRes, takeAmt) {
				console.log(recipient, giveRes, giveAmt, takeRes, takeAmt);        // 202
				/*                                                                 //
    requests should look like:                                         //
    [                                                                  //
    	// {text: "blah blah"},                                           //
    	{requester: },				requester                                       //
    	{requested resource: },		reqRes                                   //
    	{requested amount: },		reqAmt                                     //
    	{receiving resource: },		recvRes                                  //
    	{receiving amount: },		recvAmt                                    //
    	{requestNumber: },			reqNo                                        //
    	{replied: }					replied                                           //
    ]                                                                  //
    */                                                                 //
				reqs = Meteor.users.findOne({ _id: recipient }).profile.requests;  // 216
				reqs.push({ "requester": Meteor.userId(), "reqRes": takeRes, "reqAmt": parseInt(takeAmt), "recvRes": giveRes, "recvAmt": parseInt(giveAmt), "reqNo": reqs.length, "replied": false });
				Meteor.users.update({ _id: recipient }, { $set: { "profile.requests": reqs } });
                                                                       //
				// Meteor.users.findOne({_id: recipient}).profile.requests.push({"requester": Meteor.userId(), "reqRes": takeRes, "reqAmt": takeAmt, "recvRes": giveRes, "recvAmt": giveAmt});
			},                                                                  //
                                                                       //
			raiseAlert: function (person, alert) {                              // 223
				alert = { "text": alert };                                         // 224
				alrts = Meteor.users.findOne({ _id: person }).profile.alerts;      // 225
				if (alert["text"] == "clearall") {                                 // 226
					alrts = [];                                                       // 227
				} else {                                                           //
					alrts.push(alert);                                                // 230
				}                                                                  //
				Meteor.users.update({ _id: person }, { $set: { "profile.alerts": alrts } });
			},                                                                  //
                                                                       //
			exchangeResources: function (request) {                             // 235
				// givingGrp = Meteor.users.findOne({"_id": request["requester"]}, {"profile": 1})
				reqingGrp = Meteor.users.findOne({ "_id": request["requester"] }, { "profile": 1 }).profile["groupID"];
				recvGrp = Meteor.user().profile.groupID;                           // 238
                                                                       //
				finalRequesterRequestedStock = parseInt(AllStocks.findOne({ $and: [{ "gID": reqingGrp }, { "item": request["recvRes"] }] }).amount) - parseInt(request["recvAmt"]);
				finalReceiverRequestedStock = parseInt(AllStocks.findOne({ $and: [{ "gID": recvGrp }, { "item": request["recvRes"] }] }).amount) + parseInt(request["recvAmt"]);
                                                                       //
				finalRequesterReceivedStock = parseInt(AllStocks.findOne({ $and: [{ "gID": reqingGrp }, { "item": request["reqRes"] }] }).amount) + parseInt(request["reqAmt"]);
				finalReceiverReceivedStock = parseInt(AllStocks.findOne({ $and: [{ "gID": recvGrp }, { "item": request["reqRes"] }] }).amount) - parseInt(request["reqAmt"]);
                                                                       //
				AllStocks.update({ $and: [{ "gID": recvGrp }, { "item": request["recvRes"] }] }, { $set: { "amount": finalReceiverReceivedStock } });
				AllStocks.update({ $and: [{ "gID": recvGrp }, { "item": request["reqRes"] }] }, { $set: { "amount": finalReceiverRequestedStock } });
				AllStocks.update({ $and: [{ "gID": reqingGrp }, { "item": request["recvRes"] }] }, { $set: { "amount": finalRequesterReceivedStock } });
				AllStocks.update({ $and: [{ "gID": reqingGrp }, { "item": request["reqRes"] }] }, { $set: { "amount": finalRequesterRequestedStock } });
			}                                                                   //
                                                                       //
		});                                                                  //
	});                                                                   //
                                                                       //
	Accounts.onCreateUser(function (options, user) {                      // 256
		user.groupID = groupIDs[Math.floor(Math.random() * 4)];              // 257
		// We still want the default hook's 'profile' behavior.              //
		// console.log("User: ", user);                                      //
		if (options.profile == undefined) {                                  // 260
			options.profile = { "groupID": user.groupID, "requests": [], "alerts": [] };
		} else {                                                             //
			options.profile["groupID"] = user.groupID;                          // 264
			options.profile["requests"] = [];                                   // 265
			options.profile["alerts"] = [];                                     // 266
		}                                                                    //
		// console.log("Options: ", options);                                //
		if (options.profile) {                                               // 269
			// console.log(user.groupID);                                       //
			user.profile = options.profile;                                     // 271
		}                                                                    //
		// 	console.log(user.groupID);                                       //
		return user;                                                         // 274
	});                                                                   //
}                                                                      //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=tradewars-bet.js.map
